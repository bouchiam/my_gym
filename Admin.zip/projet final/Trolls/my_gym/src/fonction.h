#include <gtk/gtk.h>

typedef struct 
{
int jour;
int mois;
int annee;
}DATE;
typedef struct
{
int role;
char username[20];
char nom[20];
char prenom[20];
char password[20];
// DATE date_n;
char sexe[15];
char CIN[20];
char forfait[50];
char poids[3];
char taille[10];
char email[30];
}adherent;
enum
{
NOM,
PRENOM,
USERNAME,
PASSWORD,
FORFAIT,
//SEXE,
//CIN,
//POIDS,
//TAILLE,
//EMAIL,
//DATE,
SELECTION,
COLUMNS
};

void add (adherent a);
void affich(GtkWidget *liste);
