#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


GtkWidget *window5,*window3,*window4;
GtkWidget *window6;
GtkWidget *liste;




void
on_button_Connect_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *input1,*input2,*output;
GtkWidget *window1;
GtkWidget *window5;
window1=lookup_widget(objet_graphique,"authentification");
FILE*f;
int role; 
char username[20],password[20],user[20],pass[20];
input1=lookup_widget(objet_graphique,"entry_Username");
input2=lookup_widget(objet_graphique,"entry_Password");
output=lookup_widget(objet_graphique,"label_wrongPassword");
strcpy(username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

if ((verifier(username,password))==-1)
{
gtk_label_set_text(GTK_LABEL(output),"   ERROR \n\n\n try again !");
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_entry_set_text(GTK_ENTRY(input1),"");
}
if ((verifier(username,password))==1)
{
gtk_widget_hide(window1);

window5 = create_Admin ();
gtk_widget_show (window5);
 
//GtkWidget *treeview_ad_adh; 




//treeview_ad_adh=lookup_widget(objet_graphique,"treeview_ad_adh");
//affich(treeview_ad_adh);

}}


void
on_button_Logout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_adh_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_adh_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5;



window5=lookup_widget(objet_graphique,"Admin");
gtk_widget_hide(window5);
GtkWidget *window6;
window6 = create_ad_aj_adh ();
gtk_widget_show (window6);



}




void
on_button_ad_mo_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *liste;
  GtkWidget *window5;
  GtkListStore *store;
  GtkTreeIter iter;

char supp[50]="suppression avec succes";

adherent s,s1;
FILE* f1;
FILE* f2;
FILE* f3;
char nom [30];
char prenom [30];
char username [30];
char password [30];
char forfait [30];

char nom1 [30];
char prenom1 [30];
char username1 [30];
char password1 [30];
char forfait1 [30];


window5=lookup_widget(objet_graphique,"Admin");
liste=lookup_widget(objet_graphique,"treeview_ad_adh");
//GtkWidget *output;

f1=fopen("/home/amine/Desktop/projet final/Trolls/my_gym/src/adherent.txt","r");
if(f1!=NULL) {
while (fscanf(f1,"%s %s %s %s %s \n",nom,prenom,username,password,forfait)!=EOF){
f2=fopen("/home/amine/Desktop/projet final/Trolls/my_gym/src/suppadh.txt","r");
f3=fopen("/home/amine/Desktop/projet final/Trolls/my_gym/src/suppadh1.txt","a+");
while(fscanf(f2,"%s %s %s %s %s \n",nom1,prenom1,username1,password1,forfait1)!=EOF){
if ((strcmp(nom,nom1)==0)&&(strcmp(prenom,prenom1)==0)&&(strcmp(username,username1)==0)&&(strcmp(password,password1)==0)&&(strcmp(forfait,forfait1)==0)) {
}
else {
fprintf(f3,"%s %s %s %s %s \n",nom,prenom,username,password,forfait);
}}
fclose(f2);
fclose(f3);
}
fclose(f1);
}
remove("/home/amine/Desktop/projet final/Trolls/my_gym/src/adherent.txt");
rename("/home/amine/Desktop/projet final/Trolls/my_gym/src/suppadh1.txt","/home/amine/Desktop/projet final/Trolls/my_gym/src/adherent.txt");
//gtk_label_set_text(GTK_LABEL(output),supp);
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
gtk_list_store_clear(store);
f1=fopen("/home/amine/Desktop/projet final/Trolls/my_gym/src/adherent.txt","r");
if(f1!=NULL){
f1 = fopen("/home/amine/Desktop/projet final/Trolls/my_gym/src/adherent.txt", "r");
              while(fscanf(f1,"%s %s %s %s %s \n",nom,prenom,username,password,forfait)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, NOM, nom, PRENOM, prenom, USERNAME, username, PASSWORD,password,FORFAIT, forfait, -1); 
		}
		fclose(f1);
}

}



void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *paths, gpointer user_data) //fonction de selection date
{
    GtkTreeIter iter;
    GtkTreePath *path;
    FILE* f;
    gboolean boolean;
    gchar *nom;
    gchar *prenom;
    gchar *username;
    gchar *password;
    gchar *forfait;
   
    path = gtk_tree_path_new_from_string (paths);
    gtk_tree_model_get_iter (GTK_TREE_MODEL (user_data),&iter,path);
    gtk_tree_model_get (GTK_TREE_MODEL (user_data),&iter,SELECTION,&boolean,NOM,&nom,PRENOM,&prenom,USERNAME,&username,PASSWORD,&password,FORFAIT,&forfait,-1);
    gtk_list_store_set (user_data, &iter,SELECTION, !boolean,-1);
    if (!boolean) { //creation de la date dans un fichier tmp
    remove("/home/amine/Desktop/projet final/Trolls/my_gym/src/suppadh.txt");
    f=fopen("/home/amine/Desktop/projet final/Trolls/my_gym/src/suppadh.txt","w");
    fprintf(f,"%s %s %s %s %s \n",nom,prenom,username,password,forfait);
    fclose(f);
}

}


void
on_treeview_ad_coach_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_mo_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_coa_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_med_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_med_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_diet_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_diet_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_diet_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_kine_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_kine_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_kine_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_event_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_event_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_event_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_button__ret_ad_aj_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window6;



window6=lookup_widget(objet_graphique,"ad_aj_adh");
gtk_widget_hide(window6);
GtkWidget *window5;
window5 = create_Admin ();
gtk_widget_show (window5);
}


void
on_button_ret_ad_mod_adh_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_ad_mod_adh_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_ret_aj_coa_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_conf_aj_coa_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_ret_aj_med_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_conf_aj_med_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_ad_aj_diet_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_ad_aj_diet_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_ad_aj_kine_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_ad_aj_kine_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_ad_event_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ad_act_list_adh_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *treeview_ad_adh; 




treeview_ad_adh=lookup_widget(objet_graphique,"treeview_ad_adh");
affich(treeview_ad_adh);

}


void
on_button_conf_ad_aj_adh_clicked       (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox_ad_aj_adh_forfait; //forfait

GtkWidget *entry_ad_aj_adh_username;    //username
GtkWidget *entry_ad_aj_adh_password;  //password
GtkWidget *entry_ad_aj_adh_nom;     //nom
GtkWidget *entry_ad_aj_adh_prenom;    //prenom

DATE date_n;
adherent a;
combobox_ad_aj_adh_forfait=lookup_widget(objet_graphique,"combobox_ad_aj_adh_forfait");
entry_ad_aj_adh_nom=lookup_widget(objet_graphique,"entry_ad_aj_adh_nom");

entry_ad_aj_adh_prenom=lookup_widget(objet_graphique,"entry_ad_aj_adh_prenom");
entry_ad_aj_adh_password=lookup_widget(objet_graphique,"entry_ad_aj_adh_password");
entry_ad_aj_adh_username=lookup_widget(objet_graphique,"entry_ad_aj_adh_username");

strcpy(a.username,gtk_entry_get_text(GTK_ENTRY(entry_ad_aj_adh_username)));
strcpy(a.password,gtk_entry_get_text(GTK_ENTRY(entry_ad_aj_adh_password)));
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(entry_ad_aj_adh_nom)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(entry_ad_aj_adh_prenom)));
strcpy(a.forfait,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ad_aj_adh_forfait)));
add(a);
}

