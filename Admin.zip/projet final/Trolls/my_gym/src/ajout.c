#include <stdio.h>
#include <stdlib.h>
int main(){
FILE*f;
char username[20]; char password[20];
int role;
role=1;
f=fopen("admin.txt","a"); 
if(f!=NULL) { 
printf("Saisir les données\n");
fflush(stdin);
printf("Saisir le username\n");
scanf("%s",username);
fflush(stdin);
printf("Saisir le password\n");
scanf("%s",password);

fprintf(f,"%s %s \n",username,password);
fclose(f); 

} else
printf("Impossible d'ouvrir le fichier");
}
