int verifier (char username[20],char password[20]);
