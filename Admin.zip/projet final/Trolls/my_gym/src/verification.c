#include <stdio.h>
#include "verification.h"
#include <string.h>
int verifier (char username[20],char password[20])
 {
         FILE *f;
int s=-1;
         char pass[20]; char user[20]; int role;
         f=fopen("/home/amine/Desktop/projet final/Trolls/my_gym/src/admin.txt","r");
        if (f!=NULL)
     {
             while(fscanf(f,"%s %s %d",user,pass,&role)!=EOF)   
         {
           if ((strcmp(username,user)==0)&&(strcmp(password,pass)==0))
            {
            	s=role;
	    }
	}
     }   
	fclose(f);    
         
 	return(s);
     
 }
