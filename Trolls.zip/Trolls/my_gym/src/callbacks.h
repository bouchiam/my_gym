#include <gtk/gtk.h>


void
on_button_Connect_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_Logout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_adh_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_adh_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_mo_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_coach_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_mo_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_coa_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_med_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_med_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_diet_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_diet_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_diet_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_kine_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_kine_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_kine_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_event_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_event_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_event_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_aj_adh_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button__ret_ad_aj_adh_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_ad_mod_adh_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_mod_adh_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_ret_aj_coa_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_conf_aj_coa_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_ret_aj_med_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_conf_aj_med_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_ad_aj_diet_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_aj_diet_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_ad_aj_kine_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_aj_kine_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_event_clicked        (GtkButton       *button,
                                        gpointer         user_data);
