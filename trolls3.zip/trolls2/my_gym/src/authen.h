int authen(char login[],char password[]);
