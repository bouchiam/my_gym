#include <gtk/gtk.h>

typedef struct 
{
char jour[20];
char mois[20];
char annee[20];
}dt;
typedef struct
{
	char role[20]; 	
	char jour[50];
	char mois[50];
	char annee[50];
	char sexe[50];
	char nom[50];
	char prenom[50];
	char mail[50];
	char poids[50];
	char nt[50];
	char taille[50];
	char user[50];
	char mdp[50];
	char cin[50];
	char forfait[200];
}adherent;
enum
{
CIN,
USERNAME,
PASSWORD,
FORFAIT,
//SEXE,
//CIN,
//POIDS,
//TAILLE,
//EMAIL,
//DATE,
SELECTION,
COLUMNS
};

void add (adherent a);
void affich(GtkWidget *liste);
void modifier(char ID[],adherent a);
