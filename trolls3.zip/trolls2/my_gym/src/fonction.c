#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fonction.h"
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"


void add(adherent a)
{
FILE*f;
f=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","a+");
strcpy(a.role,"2");
//strcpy(a.sexe," ");//
//strcpy(a.CIN,"13242258");
/*strcpy(a.date_n.jour,"   ");
strcpy(a.date_n.mois,"   ");
strcpy(a.date_n.annee,"   ");
strcpy(a.poids," ");
strcpy(a.taille," ");
strcpy(a.email," ");
strcpy(a.tel," ");*/
if(f!=NULL)
{

fprintf(f,"%s %s %s %s * * * * * * * * * *\n",a.cin,a.user,a.mdp,a.forfait);
fclose(f);
}
}

void affich(GtkWidget *liste)
{
enum
{
CIN,
USERNAME,
PASSWORD,
FORFAIT,
//SEXE,
//CIN,
//POIDS,
//TAILLE,
//EMAIL,
//DATE,
SELECTION,
COLUMNS
};
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;


	
	char cin[20];
	//char prenom[20];
	char username[20];
	char password[20];
	//char date_n;
	//char sexe[15];
	//char cin[20];
	char forfait[50];
	//char poids[3];
	//char taille[10];
	//char email[30];
        store=NULL;
	adherent a;
       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	

	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  cin", renderer, "text",CIN, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		/*renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" prenom", renderer, "text",PRENOM, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);*/	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  username", renderer, "text",USERNAME, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  password", renderer, "text",PASSWORD, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  forfait", renderer, "text",FORFAIT, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_toggle_new ();
		column = gtk_tree_view_column_new_with_attributes(" select", renderer, "active",SELECTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		//renderer = gtk_cell_renderer_text_new ();
		//column = gtk_tree_view_column_new_with_attributes("  sexe", renderer, "text",SEXE, NULL);
		//gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		//renderer = gtk_cell_renderer_text_new ();
		//column = gtk_tree_view_column_new_with_attributes("  poids", renderer, "text",POIDS, NULL);
		//gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		//renderer = gtk_cell_renderer_text_new ();
		//column = gtk_tree_view_column_new_with_attributes("  taille", renderer, "text",TAILLE, NULL);
		//gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);



               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_BOOLEAN);

	f = fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 


	{ f = fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt", "a+");
              while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.cin,a.user,a.mdp,a.forfait,a.nom,
					a.prenom,a.jour,a.mois,a.annee,a.sexe,a.nt,a.mail,a.poids,a.taille)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, CIN, a.cin, USERNAME, a.user,PASSWORD,a.mdp,FORFAIT,a.forfait, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
   g_signal_connect(G_OBJECT(renderer),"toggled", (GCallback)toggled_func,store);
	}
}
void modifier(char ID[],adherent a)
{			

			adherent a1;
    		    adherent ad ;
   		    FILE* F;
		    FILE* F_temp;
		    F=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","a+");
		    F_temp=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","a+");

		    while(fscanf(F,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille)!=EOF)
		    {

			if (strcmp(ID,ad.cin)==0)

			   { fprintf(F_temp,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.cin,a.user,a.mdp,a1.forfait,a.nom,
					a.prenom,a.jour,a.mois,a.annee,a.sexe,a.nt,a.mail,a.poids,a.taille);}
			else if (strcmp(ID,ad.cin)!=0)
 {	    fprintf(F_temp,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille);
}
		    };

		    fclose(F);
		    fclose(F_temp);
		    remove("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
		    rename("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
}




