#include "affichage.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
void afficher (GtkWidget *treeview_adh_rdv)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn * column;
GtkTreeIter iter;
GtkListStore *store;
char nom[50];
char prenom[50];
char date[50];
char lieu[50];
char nation[50];
char num[50];
FILE *f;
store=NULL;
store=gtk_tree_view_get_model(treeview_adh_rdv);
if (store == NULL)
{
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("JOUR",renderer,"text",NOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_adh_rdv),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("MOIS",renderer,"text",PRENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_adh_rdv),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("ANNEE",renderer,"text",DATE,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_adh_rdv),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("HORAIRE",renderer,"text",LIEU,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_adh_rdv),column);

		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("NOM",renderer,"text",NATION,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_adh_rdv),column);
		
		renderer=gtk_cell_renderer_text_new();
		column=gtk_tree_view_column_new_with_attributes("NUMERO",renderer,"text",NUM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_adh_rdv),column);


}
	store=gtk_list_store_new(COL,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/personelreserve.txt","r");
if (f == NULL ) {return;}
else
{
while (fscanf(f," %s %s %s %s %s %s",nom,prenom,date,lieu,nation,num)!=EOF) {

	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,NOM,nom,PRENOM,prenom,DATE,date,LIEU,lieu,NATION,nation,NUM,num,-1);
}
fclose(f);
}
	gtk_tree_view_set_model(GTK_TREE_VIEW(treeview_adh_rdv),GTK_TREE_MODEL(store));
	g_object_unref(store);
}
