#include <gtk/gtk.h>
typedef struct
{
int jour;
int  mois;
int  annee;
}date;
typedef struct
{
//char specilite[50];
char personel[50];
char horaire[50];
date dt_rd;
char num[50];
}rdv;

void ajoutrdv(rdv r2);
void supprimer_rdv(char log[]);
