#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "authen.h"
int authen(char login[],char password[])
{
	FILE *f;
	char username[20];
	char PassWord[20];
	int role;
f=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/users.txt","r");
if(f!=NULL)
{
	while(fscanf(f,"%s %s %d",username,PassWord,&role)!=EOF)
	{
		if((strcmp(login,username)==0) && strcmp(password,PassWord)==0)
{
return(role);
}
}
return 0;
}
fclose(f);
}
