#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <string.h>
#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "authen.h"
#include "reservation.h"
#include "affichage.h"
#include "profil.h"
#include "fonction.h"

	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *output;
	GtkWidget *ad_adh;
	GtkWidget *admin;
	GtkWidget *authentification;
	GtkWidget *adh_aj_rdv;
	GtkWidget *adh_supp_rdv;
	GtkWidget *adh_mo_profil;
	GtkWidget *treeview_ad_adh;
	
	
	
	
void
on_button_Connect_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	char login[20];
	char password[20];
	GtkWidget *adherent;
input1=lookup_widget(objet_graphique,"entry_Username");
input2=lookup_widget(objet_graphique,"entry_Password");
output=lookup_widget(objet_graphique,"label_wrongPassword");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input2)));

if(authen(login,password)==1)
{
 admin = create_admin();
 gtk_widget_show(admin);

 gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"authentification")));

}
else if(authen(login,password)==2)
{
 adherent = create_adherent();
 gtk_widget_show(adherent);

 gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"authentification")));
 GtkWidget *treeview_adh_rdv;
 treeview_adh_rdv = lookup_widget(adherent,"treeview_adh_rdv");
 afficher (treeview_adh_rdv);
}

else{
	gtk_label_set_text(GTK_LABEL(output),"Wrong PASSWORD and/or USER ID.");
    }

}

void
on_button_ad_Logout_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
authentification= create_authentification();
 gtk_widget_show(authentification);

 gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"admin")));
 
}


void
on_treeview_ad_adh_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_adh_clicked            (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ad_aj_adh;
ad_aj_adh = create_ad_aj_adh();
 gtk_widget_show(ad_aj_adh);
}


void
on_button_ad_mo_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5;



window5=lookup_widget(objet_graphique,"Admin");
gtk_widget_hide(window5);
GtkWidget *window6;
window6 = create_ad_aj_adh ();
gtk_widget_show (window6);
}


void
on_button_ad_supp_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *liste;
  GtkWidget *window5;
  GtkListStore *store;
  GtkTreeIter iter;

char supp[50]="suppression avec succes";

adherent ad,a;
FILE* f1;
FILE* f2;
FILE* f3;
char cin [30];
//char prenom [30];
char username [30];
char password [30];
char forfait [30];

char cin1 [30];
//char prenom1 [30];
char username1 [30];
char password1 [30];
char forfait1 [30];


window5=lookup_widget(objet_graphique,"Admin");
liste=lookup_widget(objet_graphique,"treeview_ad_adh");
//GtkWidget *output;

f1=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","r");
if(f1!=NULL) {
while (fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille)!=EOF)
			{
f2=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/suppadh.txt","r");
f3=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/suppadh1.txt","a+");
while(fscanf(f2,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.cin,a.user,a.mdp,a.forfait,a.nom,
					a.prenom,a.jour,a.mois,a.annee,a.sexe,a.nt,a.mail,a.poids,a.taille)!=EOF)
{
if ((strcmp(ad.cin,a.cin)==0)&&(strcmp(ad.user,a.user)==0)&&(strcmp(ad.mdp,a.mdp)==0)&&(strcmp(ad.forfait,a.forfait)==0)) {
}
else {
fprintf(f3,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille);
}}
fclose(f2);
fclose(f3);
}
fclose(f1);
}
remove("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
rename("/home/majdich016/Desktop/trolls2/my_gym/src/suppadh1.txt","/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
//gtk_label_set_text(GTK_LABEL(output),supp);
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
gtk_list_store_clear(store);
f1=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","r");
if(f1!=NULL){
f1 = fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt", "r");
              while(fscanf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, CIN, ad.cin, USERNAME, ad.user, PASSWORD,ad.mdp,FORFAIT, ad.forfait, -1); 
		}
		fclose(f1);
}

}



void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *paths, gpointer user_data) //fonction de selection date
{
    GtkTreeIter iter;
    GtkTreePath *path;
    FILE* f;
    gboolean boolean;
    gchar *cin;
    //gchar *prenom;
    gchar *username;
    gchar *password;
    gchar *forfait;
   
    path = gtk_tree_path_new_from_string (paths);
    gtk_tree_model_get_iter (GTK_TREE_MODEL (user_data),&iter,path);
    gtk_tree_model_get (GTK_TREE_MODEL (user_data),&iter,SELECTION,&boolean,CIN,&cin,USERNAME,&username,PASSWORD,&password,FORFAIT,&forfait,-1);
    gtk_list_store_set (user_data, &iter,SELECTION, !boolean,-1);
    if (!boolean) { //creation de la date dans un fichier tmp
    remove("/home/majdich016/Desktop/trolls2/my_gym/src/suppadh.txt");
    f=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/suppadh.txt","w");
    fprintf(f,"%s %s %s %s \n",cin,username,password,forfait);
    fclose(f);
}

}



void
on_treeview_ad_coach_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_mo_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_coa_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_med_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_med_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_diet_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_diet_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_diet_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_kine_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_kine_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_kine_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_treeview_ad_event_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_ad_aj_event_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_supp_event_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button__ret_ad_aj_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window6;



window6=lookup_widget(objet_graphique,"ad_aj_adh");
gtk_widget_hide(window6);
GtkWidget *window5;
//window5 = create_admin ();
//gtk_widget_show (window5);
}


void
on_button_conf_ad_aj_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox_ad_aj_adh_forfait; //forfait
GtkWidget *combobox_aj_adh_role; //role
GtkWidget *entry_ad_aj_adh_username;    //username
GtkWidget *entry_ad_aj_adh_password;  //password
GtkWidget *entry_ad_aj_adh_cin;     //cin


dt date_n;
adherent a;
combobox_ad_aj_adh_forfait=lookup_widget(objet_graphique,"combobox_ad_aj_adh_forfait");
combobox_aj_adh_role=lookup_widget(objet_graphique,"combobox_aj_adh_role");
entry_ad_aj_adh_cin=lookup_widget(objet_graphique,"entry_ad_aj_adh_cin");
entry_ad_aj_adh_password=lookup_widget(objet_graphique,"entry_ad_aj_adh_password");
entry_ad_aj_adh_username=lookup_widget(objet_graphique,"entry_ad_aj_adh_username");

strcpy(a.user,gtk_entry_get_text(GTK_ENTRY(entry_ad_aj_adh_username)));
strcpy(a.mdp,gtk_entry_get_text(GTK_ENTRY(entry_ad_aj_adh_password)));
strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(entry_ad_aj_adh_cin)));
strcpy(a.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_aj_adh_role)));
strcpy(a.forfait,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ad_aj_adh_forfait)));
add(a);
}


void
on_button_conf_ad_mod_adh_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char ID[20];
adherent a1;
adherent a;
adherent ad;

GtkWidget *input1;
GtkWidget *input2;

input1= lookup_widget(objet_graphique,"combobox_ad_mod_adh_forfait");
input2= lookup_widget(objet_graphique,"entry_rech_ad_mo_profile");
strcpy(a1.forfait,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));

strcpy(ID,gtk_entry_get_text(GTK_ENTRY(input2)));

   		    FILE* F;
		    FILE* F_temp;
		    F=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","a+");
		    F_temp=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","a+");

		    while(fscanf(F,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille)!=EOF)
		    {

			if (strcmp(ID,ad.cin)==0)

			   { fprintf(F_temp,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.cin,a.user,a.mdp,a1.forfait,a.nom,
					a.prenom,a.jour,a.mois,a.annee,a.sexe,a.nt,a.mail,a.poids,a.taille);}
			else if (strcmp(ID,ad.cin)!=0)
 {	    fprintf(F_temp,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille);
}
		    };

		    fclose(F);
		    fclose(F_temp);
		    remove("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
		    rename("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
/*modifier(ID,a);

gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_entry_set_text(GTK_ENTRY(input3),"");
gtk_entry_set_text(GTK_ENTRY(input4),"");
gtk_entry_set_text(GTK_ENTRY(input5),"");
gtk_entry_set_text(GTK_ENTRY(input6),"");
gtk_entry_set_text(GTK_ENTRY(input7),"");
gtk_entry_set_text(GTK_ENTRY(input8),"");
gtk_entry_set_text(GTK_ENTRY(input9),"");
gtk_entry_set_text(GTK_ENTRY(input10),"");
gtk_entry_set_text(GTK_ENTRY(input11),"");
gtk_entry_set_text(GTK_ENTRY(input12),"");
gtk_entry_set_text(GTK_ENTRY(input13),"");
gtk_entry_set_text(GTK_ENTRY(input14),"");

*/
}


void
on_button_ret_ad_mod_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"ad_mod_adh")));
}


/*void
on_button_rech_ad_mo_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)*/
//{
/*char log[20];
adherent ad;
GtkWidget *output1;
GtkWidget *input1;

input1= lookup_widget(objet_graphique, "entry_rech_ad_mo_profile");
output1= lookup_widget(objet_graphique, "combobox_ad_mod_adh_forfait");

strcpy(log,gtk_entry_get_text(GTK_ENTRY(input1)));

FILE* F;
    F=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","r+");
	if (F!=NULL)
{
         while(!feof(F))
{
	(fscanf(F,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille)!=EOF);


	if (strcmp(log,ad.cin)==0)

{
//strcpy(a.forfait,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ad_aj_adh_forfait)));
gtk_combo_box_set_active(GTK_COMBO_BOX(output1),0);

}
}
} fclose(F);*/
//}


void
on_button_ad_conf_aj_coa_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_ret_aj_coa_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_ad_mo_coa_profil_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_ret_aj_med_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ad_conf_aj_med_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_ad_aj_diet_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_ad_aj_diet_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_ad_aj_kine_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_ad_aj_kine_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_ad_aj_event_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_ad_event_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_profile_adh_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 adh_mo_profil= create_adh_mo_profil();
 gtk_widget_show(adh_mo_profil);
}


void
on_button_logout_adh_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 authentification= create_authentification();
 gtk_widget_show(authentification);

 gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"adherent")));
 
}


void
on_button_refr_adh_coa_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_refr_adh_diet_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_refr_adh_kine_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_refr_adh_fichmed_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_adh_aj_rdv_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 adh_aj_rdv = create_adh_aj_rdv();
 gtk_widget_show(adh_aj_rdv);

}


void
on_button_adh_supp_rdv_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 adh_supp_rdv = create_adh_supp_rdv();
 gtk_widget_show(adh_supp_rdv);
}


void
on_button_rech_adh_supp_rdv_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ref_coa_fichmed_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ref_coa_rdv_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_coa_aj_disp_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_coa_supp_dispo_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_coa_mo_profil_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_coa_mo_profil_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_coa_aj_disp_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_coa_supp_disp_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_coa_supp_disp_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_logout_med_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_med_supp_fichmed_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_med_mo_fichmed_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_med_aj_fichmed_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ref_med_rdv_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_med_supp_disp_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_med_aj_disp_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_med_mo_profil_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_med_aj_fichmed_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_med_aj_fichmed_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_med_mo_fichmed_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_med_mo_fichmed_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_med_mo_fichmed_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_supp_med_supp_fichmed_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_med_supp_fichmed_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_med_aj_disp_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_med_supp_disp_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_supp_disp_med_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_logout_diet_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ref_diet_fichmed_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_diet_supp_disp_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_diet_aj_disp_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ref_diet_rdv_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_diet_mo_profil_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_diet_aj_disp_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_supp_diet_disp_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_diet_supp_disp_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_diet_mo_prof_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_diet_mo_prof_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_med_mo_profil_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_med_mo_profil_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ref_kine_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ref_kine_rdv_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_kine_supp_disp_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_kine_aj_disp_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_kine_mo_profil_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_logout_kine_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_kine_aj_disp_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_kine_supp_disp_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_ret_kine_mo_profil_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_conf_kine_mo_profil_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{

}

void
on_button_supp_adh_supp_rdv_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char ID[50];
GtkWidget *adherent;
GtkWidget *input1;

input1 = lookup_widget(objet_graphique,"entry_adh_supp_rdv");

strcpy(ID, gtk_entry_get_text(GTK_ENTRY(input1)));

supprimer_rdv(ID);

GtkWidget *treeview_adh_rdv;
 treeview_adh_rdv = lookup_widget(adherent,"treeview_adh_rdv");
 afficher (treeview_adh_rdv);
}

void
on_button_ret_adh_mo_profil_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 gtk_widget_hide(GTK_WIDGET(lookup_widget(objet_graphique,"adh_mo_profil")));
}


void
on_button_val_adh_aj_rdv_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button_conf_adh_aj_rdv_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *combobox_adh_aj_rdv_hr;
GtkWidget *combobox_adh_aj_rdv_pers;
GtkWidget *treeview_adh_rdv;
GtkWidget *input1;
GtkWidget *output;
GtkWidget *adherent;
date dt_rd;
rdv r2;

treeview_adh_rdv = lookup_widget(adherent,"treeview_adh_rdv");

input1= lookup_widget(objet_graphique,"entry_num_rdv_adh");
output=lookup_widget(objet_graphique,"label_adh_aj_rdv_reuss");

combobox_adh_aj_rdv_hr=lookup_widget(objet_graphique,"combobox_adh_aj_rdv_hr");
combobox_adh_aj_rdv_pers=lookup_widget(objet_graphique,"combobox_adh_aj_rdv_pers");
jour=lookup_widget(objet_graphique,"spinbutton_adh_aj_rdv_jdate");
mois=lookup_widget(objet_graphique,"spinbutton_adh_aj_rdv_mdate");
annee=lookup_widget(objet_graphique,"spinbutton_adh_aj_rdv_adate");
strcpy(r2.horaire,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_adh_aj_rdv_hr)));
strcpy(r2.personel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_adh_aj_rdv_pers)));
r2.dt_rd.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
r2.dt_rd.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
r2.dt_rd.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(r2.num,gtk_entry_get_text(GTK_ENTRY(input1)));

ajoutrdv(r2);

gtk_label_set_text(GTK_LABEL(output),"Reservation réusite!.");

afficher (treeview_adh_rdv);
}


void
on_button_conf_adh_mo_profil_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char ID[20];

Personne a;
Personne ad;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input10;
GtkWidget *input11;
GtkWidget *input12;
GtkWidget *input13;
GtkWidget *input9;
GtkWidget *input14;


input1= lookup_widget(objet_graphique,"entry_adh_mo_profile_nom");
input2= lookup_widget(objet_graphique, "entry_adh_mo_profile_prenom");
input3= lookup_widget(objet_graphique,"entry_adh_mo_profile_jdt");
input4= lookup_widget(objet_graphique, "entry_adh_mo_profile_mdt");
input5= lookup_widget(objet_graphique,"entry_adh_mo_profile_adt");
input6= lookup_widget(objet_graphique, "entry_adh_mo_profile_sx");
input7= lookup_widget(objet_graphique,"entry_adh_mo_profile_tlf");
input8= lookup_widget(objet_graphique, "entry_adh_mo_profile_mail");
input9= lookup_widget(objet_graphique,"entry_adh_mo_profile_poids");
input10= lookup_widget(objet_graphique, "entry_adh_mo_profile_ta");
input11= lookup_widget(objet_graphique,"entry_adh_mo_profile_usrn");
input12= lookup_widget(objet_graphique, "entry_adh_mo_profile_pass");
input13= lookup_widget(objet_graphique, "entry_adh_mo_profile_fr");
input14= lookup_widget(objet_graphique, "entry_adh_mo_profile_cin");

strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(a.user,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(a.mdp,gtk_entry_get_text(GTK_ENTRY(input12)));
strcpy(a.forfait,gtk_entry_get_text(GTK_ENTRY(input13)));
strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(input14)));
strcpy(a.jour,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(a.mois,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(a.annee,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(a.nt,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(a.mail,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(a.taille,gtk_entry_get_text(GTK_ENTRY(input10)));

strcpy(ID,gtk_entry_get_text(GTK_ENTRY(input14)));

modifier_rdv(ID,a);

gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_entry_set_text(GTK_ENTRY(input3),"");
gtk_entry_set_text(GTK_ENTRY(input4),"");
gtk_entry_set_text(GTK_ENTRY(input5),"");
gtk_entry_set_text(GTK_ENTRY(input6),"");
gtk_entry_set_text(GTK_ENTRY(input7),"");
gtk_entry_set_text(GTK_ENTRY(input8),"");
gtk_entry_set_text(GTK_ENTRY(input9),"");
gtk_entry_set_text(GTK_ENTRY(input10),"");
gtk_entry_set_text(GTK_ENTRY(input11),"");
gtk_entry_set_text(GTK_ENTRY(input12),"");
gtk_entry_set_text(GTK_ENTRY(input13),"");
gtk_entry_set_text(GTK_ENTRY(input14),"");


}


void
on_button_rech_adh_data_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char log[20];
Personne P;


GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
GtkWidget *output6;
GtkWidget *output7;
GtkWidget *output8;
GtkWidget *output9;
GtkWidget *output10;
GtkWidget *output11;
GtkWidget *output12;
GtkWidget *output13;

GtkWidget *input14;




output1= lookup_widget(objet_graphique,"entry_adh_mo_profile_nom");
output2= lookup_widget(objet_graphique, "entry_adh_mo_profile_prenom");
output3= lookup_widget(objet_graphique,"entry_adh_mo_profile_jdt");
output4= lookup_widget(objet_graphique, "entry_adh_mo_profile_mdt");
output5= lookup_widget(objet_graphique,"entry_adh_mo_profile_adt");
output6= lookup_widget(objet_graphique, "entry_adh_mo_profile_sx");
output7= lookup_widget(objet_graphique,"entry_adh_mo_profile_tlf");
output8= lookup_widget(objet_graphique, "entry_adh_mo_profile_mail");
output9= lookup_widget(objet_graphique,"entry_adh_mo_profile_poids");
output10= lookup_widget(objet_graphique, "entry_adh_mo_profile_ta");
output11= lookup_widget(objet_graphique,"entry_adh_mo_profile_usrn");
output12= lookup_widget(objet_graphique, "entry_adh_mo_profile_pass");
output13= lookup_widget(objet_graphique, "entry_adh_mo_profile_fr");

input14= lookup_widget(objet_graphique, "entry_adh_mo_profile_cin");


strcpy(log,gtk_entry_get_text(GTK_ENTRY(input14)));

FILE* F;
    F=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","r+");
	if (F!=NULL)
{
         while(!feof(F))
{
	fscanf(F,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n ",P.cin,P.user,P.mdp,P.forfait,P.nom,
					P.prenom,P.jour,P.mois,P.annee,P.sexe,P.nt,P.mail,P.poids,P.taille)!=EOF;


	if (strcmp(log,P.cin)==0)

{

gtk_entry_set_text(GTK_ENTRY(output1),P.nom);
gtk_entry_set_text(GTK_ENTRY(output2),P.prenom);
gtk_entry_set_text(GTK_ENTRY(output3),P.jour);
gtk_entry_set_text(GTK_ENTRY(output4),P.mois);
gtk_entry_set_text(GTK_ENTRY(output5),P.annee);
gtk_entry_set_text(GTK_ENTRY(output6),P.sexe);
gtk_entry_set_text(GTK_ENTRY(output7),P.nt);
gtk_entry_set_text(GTK_ENTRY(output8),P.mail);
gtk_entry_set_text(GTK_ENTRY(output9),P.poids);
gtk_entry_set_text(GTK_ENTRY(output10),P.taille);
gtk_entry_set_text(GTK_ENTRY(output11),P.user);
gtk_entry_set_text(GTK_ENTRY(output12),P.mdp);
gtk_entry_set_text(GTK_ENTRY(output13),P.forfait);

}
}
} fclose(F);
}


void
on_button_ad_act_list_adh_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *treeview_ad_adh; 

treeview_ad_adh=lookup_widget(objet_graphique,"treeview_ad_adh");
affich(treeview_ad_adh);

}


void
on_button_ad_mo_adh_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *ad_mod_adh; 
ad_mod_adh= create_ad_mod_adh();
 gtk_widget_show(ad_mod_adh);
}


void
on_button_rech_ad_mo_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char log[20];
adherent ad;
GtkWidget *output1;
GtkWidget *input1;

input1= lookup_widget(objet_graphique, "entry_rech_ad_mo_profile");
output1= lookup_widget(objet_graphique, "combobox_ad_mod_adh_forfait");

strcpy(log,gtk_entry_get_text(GTK_ENTRY(input1)));

FILE* F;
    F=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","r+");
	if (F!=NULL)
{
         while(!feof(F))
{
	(fscanf(F,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille)!=EOF);


	if (strcmp(log,ad.cin)==0)

{
//strcpy(a.forfait,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_ad_aj_adh_forfait)));
gtk_combo_box_set_active(GTK_COMBO_BOX(output1),0);
}
}
}
}
