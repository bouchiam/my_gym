#include <stdio.h>
#include <gtk/gtk.h>

typedef struct {
	char jour[50];
	char mois[50];
	char annee[50];
	char horaire[50];
	char nom[50];
	char n[50];
	
}Personel;
enum
{
 NOM=0,
 PRENOM,
 DATE,
 LIEU,
 NATION,
 NUM,
 COL
}; 
void afficher (GtkWidget *treeview_adh_rdv);




