#include <gtk/gtk.h>

void
on_button_Connect_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ad_Logout_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview_ad_adh_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_adh_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ad_mo_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ad_supp_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview_ad_coach_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_mo_coa_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_coa_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_med_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_med_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_diet_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_diet_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_diet_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_kine_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_kine_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_kine_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_ad_event_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ad_aj_event_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_supp_event_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button__ret_ad_aj_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_conf_ad_aj_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_conf_ad_mod_adh_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ret_ad_mod_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_ad_mo_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ad_conf_aj_coa_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_ret_aj_coa_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_ad_mo_coa_profil_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_ret_aj_med_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ad_conf_aj_med_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_ad_aj_diet_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_aj_diet_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_ad_aj_kine_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_aj_kine_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_ad_aj_event_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_ad_event_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_profile_adh_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_logout_adh_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_refr_adh_coa_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_refr_adh_diet_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_refr_adh_kine_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_refr_adh_fichmed_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_adh_aj_rdv_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_adh_supp_rdv_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_adh_supp_rdv_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ref_coa_fichmed_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ref_coa_rdv_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_coa_aj_disp_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_coa_supp_dispo_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_coa_mo_profil_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_coa_mo_profil_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_coa_aj_disp_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_coa_supp_disp_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_coa_supp_disp_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_logout_med_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_med_supp_fichmed_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_med_mo_fichmed_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_med_aj_fichmed_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ref_med_rdv_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_med_supp_disp_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_med_aj_disp_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_med_mo_profil_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_med_aj_fichmed_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_med_aj_fichmed_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_med_mo_fichmed_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_med_mo_fichmed_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_med_mo_fichmed_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_med_supp_fichmed_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_med_supp_fichmed_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_med_aj_disp_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_med_supp_disp_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_disp_med_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_logout_diet_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ref_diet_fichmed_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_diet_supp_disp_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_diet_aj_disp_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ref_diet_rdv_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_diet_mo_profil_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_diet_aj_disp_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_diet_disp_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_diet_supp_disp_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_diet_mo_prof_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_diet_mo_prof_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_med_mo_profil_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_med_mo_profil_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ref_kine_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ref_kine_rdv_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_kine_supp_disp_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_kine_aj_disp_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_kine_mo_profil_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_logout_kine_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_kine_aj_disp_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_kine_supp_disp_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ret_kine_mo_profil_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_conf_kine_mo_profil_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supp_adh_supp_rdv_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ret_adh_mo_profil_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_val_adh_aj_rdv_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_conf_adh_aj_rdv_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_conf_adh_mo_profil_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_adh_data_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ad_act_list_adh_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void toggled_func(GtkCellRendererToggle *cell_renderer, gchar *paths, gpointer user_data);

void
on_button_ad_mo_adh_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_ad_mo_adh_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
