#include "profil.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
void modifier_rdv(char ID[],Personne a)
{

    		    Personne ad ;
   		    FILE* F;
		    FILE* F_temp;
		    F=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt","a+");
		    F_temp=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","a+");

		    while(fscanf(F,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille)!=EOF)
		    {

			if (strcmp(ID,ad.cin)==0)

			   { fprintf(F_temp,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",a.cin,a.user,a.mdp,a.forfait,a.nom,
					a.prenom,a.jour,a.mois,a.annee,a.sexe,a.nt,a.mail,a.poids,a.taille);}
			else if (strcmp(ID,ad.cin)!=0)
 {	    fprintf(F_temp,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s\n",ad.cin,ad.user,ad.mdp,ad.forfait,ad.nom,
					ad.prenom,ad.jour,ad.mois,ad.annee,ad.sexe,ad.nt,ad.mail,ad.poids,ad.taille);
}
		    };

		    fclose(F);
		    fclose(F_temp);
		    remove("/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
		    rename("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","/home/majdich016/Desktop/trolls2/my_gym/src/adherent.txt");
}
