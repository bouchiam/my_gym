#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reservation.h"

void ajoutrdv(rdv r2)
{

FILE*f;
f=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/personelreserve.txt","a+");

if(f!=NULL)
{

  fprintf(f,"%d %d %d %s %s %s\n",r2.dt_rd.jour,r2.dt_rd.mois,r2.dt_rd.annee,r2.horaire,r2.personel,r2.num);
fclose(f);
}
}
void supprimer_rdv(char log[])
{
	char nom[40];
	char prenom[40];
	char date[40];
	char lieu[40];
	char nation[40];
	char num[40];
	

        FILE *F; 
	FILE *Ftemp;
	F=fopen("/home/majdich016/Desktop/trolls2/my_gym/src/personelreserve.txt","a+");
	Ftemp=fopen ("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","w+");
	if (F!=NULL){
	
		while (fscanf(F,"%s %s %s %s %s %s\n",nom,prenom,date,
                                                    lieu,nation,num)!=EOF)
			{
			if(strcmp(num,log)!=0)
				{
				fprintf(Ftemp,"%s %s %s %s %s %s\n",nom,prenom,date,
                                                    lieu,nation,num);
				}
			}
	
fclose(Ftemp);
fclose(F);
		    }
remove ("/home/majdich016/Desktop/trolls2/my_gym/src/personelreserve.txt");
rename ("/home/majdich016/Desktop/trolls2/my_gym/src/temp.txt","/home/majdich016/Desktop/trolls2/my_gym/src/personelreserve.txt");
}

